package com.praphull.webtoapp;

import android.os.Bundle;
import android.app.Activity;
import android.graphics.Bitmap;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;

public class MainActivity extends Activity {

	WebView web;
	ProgressBar progressBar;
	
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        web = (WebView) findViewById(R.id.webView1);
        
        progressBar = (ProgressBar) findViewById(R.id.progressBar1);
        
        web.setWebViewClient(new myWebClient());
        web.getSettings().setJavaScriptEnabled(true);
        web.loadUrl("http://www.youtube.com");
        
    }
    public class myWebClient extends WebViewClient
    {
    	
    	@Override
    	
    	public void onPageStarted(WebView view, String url, Bitmap favicon){
    		
    		super.onPageStarted(view, url, favicon);
    	}
    	
    	@Override
    	public boolean shouldOverrideUrlLoading(WebView view, String url){
    		view.loadUrl(url);
    		return true;
    	}
    	
    	@Override
    	
    	public void onPageFinished(WebView view, String url){
    		super.onPageFinished(view, url);
    		
    		progressBar.setVisibility(View.GONE);
    	}
    }

public boolean onKeyDown(int keyCode, KeyEvent event)
{
	if((keyCode == KeyEvent.KEYCODE_BACK) && web.canGoBack()){
		web.goBack();
		return true;
	}
	return super.onKeyDown(keyCode, event);
}
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
    
}
